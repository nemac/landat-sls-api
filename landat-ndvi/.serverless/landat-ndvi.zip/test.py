import calendar
import json
import os
import rasterio
import re
from Config import *
from rasterio.session import AWSSession
from rasterio.vrt import WarpedVRT

print('loading function')
tifs = LANDAT_NDVI_FILES
ndviValues = []
try:
  # Open each tif from object store and grab the ndvi value for a lat/long point
  for tif in tifs:
    times = []
    # Extract the year from the tif file
    year = int(tif[4:8])
    #dates_file = LEAP_DATES_FILE if calendar.isleap(year) else NONLEAP_DATES_FILE
    #f = open(dates_file)
    #dates = [ x.rstrip('\n') for x in f.readlines() ]
    #f.close()
    dates_list = LEAP_DATES_LIST if calendar.isleap(year) else NONLEAP_DATES_LIST
    #times = [ '' + str(year) + x for x in dates ]
    times = [ '' + str(year) + x for x in dates_list ]
    # The last timepoint rolls over to the next year
    times[-1] = '' + str(year+1) + times[-1][4:]
    datasource = "/Users/jbliss/ndvi_archive/COtiffs/%s" % (tif)
    with rasterio.open(datasource) as src:
      with WarpedVRT(src, crs='EPSG:4326') as vrt:
        x = -82.54577636718751
        y = 35.58138418324621
        coords = [(x, y)]
        result_gen = vrt.sample(coords, list(range(1, 46)))
        for i, v in enumerate(next(result_gen)):
          ndviValues.append("%s,%s" % (times[i],v))
  print(ndviValues)

except Exception as e: print(e)
